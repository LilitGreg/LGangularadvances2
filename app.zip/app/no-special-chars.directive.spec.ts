import { NoSpecialCharsDirective } from './no-special-chars.directive';

describe('NoSpecialCharsDirective', () => {
  it('should create an instance', () => {
    const directive = new NoSpecialCharsDirective();
    expect(directive).toBeTruthy();
  });
});
